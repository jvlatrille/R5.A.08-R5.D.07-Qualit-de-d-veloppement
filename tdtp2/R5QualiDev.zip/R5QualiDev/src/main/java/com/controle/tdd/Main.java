package com.controle.tdd;

public class Main {
    public static void main(String[] args) {
        for (int i=1; i<=20; i++) {
            System.out.println(FizzBuzz.de(i));
        }
    }
}