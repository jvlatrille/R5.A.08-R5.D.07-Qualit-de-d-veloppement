package com.controle.tdd;

public class FizzBuzz {
    public static String de(int nbre) {
        return "";
    }
}
